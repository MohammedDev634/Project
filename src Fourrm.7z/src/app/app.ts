import { Component } from '@angular/core';
import { ForumCreate } from './forum-create/forum-create';
import { ForumList } from './forum-list/forum-list';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.html',
  imports: [ForumCreate, ForumList]  // import all standalone child components
})
export class App {}
