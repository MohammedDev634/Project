import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'forum-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="post">
      <h5>{{ post.title }}</h5>
      <p>{{ post.content }}</p>
      <img [src]="post.imageUrl" alt="Post image" width="100">
      <button (click)="likePost()">Like</button>
      <span>Likes: {{ post.likes }}</span>
    </div>
  `,
  styles: [`
    .post { border: 1px solid #ccc; padding: 8px; margin: 5px 0; border-radius: 5px; background: rgba(255,255,255,0.8); }
    .post button { margin-right: 5px; padding: 5px 10px; cursor: pointer; }
  `]
})
export class ForumDetail {
  @Input() post!: { title: string; content: string; likes: number; imageUrl: string };

  likePost() { this.post.likes++; }
}
