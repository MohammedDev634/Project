import { Component } from '@angular/core';
import { Home } from './home/home';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [Home],
  template: `<home-screen></home-screen>`
})
export class AppComponent {}
