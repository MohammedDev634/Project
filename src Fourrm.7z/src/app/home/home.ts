import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Account } from '../account/account';
import { Settings } from '../settings/settings';

@Component({
  selector: 'home-screen',
  standalone: true,
  imports: [CommonModule, FormsModule, Account, Settings],
  template: `
    <div class="home-container">
      <h2>Welcome to the App!</h2>

      <!-- Search bar -->
      <div class="search-bar-container">
        <input [(ngModel)]="searchQuery" placeholder="Search location..." class="search-bar">
        <button (click)="searchLocation()">Search</button>
      </div>

      <!-- Map placeholder -->
      <div class="map">
        <p>Map goes here</p>
      </div>

      <!-- Buttons for account/settings -->
      <div class="home-buttons">
        <button (click)="toggleAccount()">Account</button>
        <button (click)="toggleSettings()">Settings</button>
      </div>

      <!-- Account Section -->
      <div *ngIf="showAccount" class="section">
        <account></account>
      </div>

      <!-- Settings Section -->
      <div *ngIf="showSettings" class="section">
        <settings-screen></settings-screen>
      </div>
    </div>
  `,
  styles: [`
    .home-container { max-width: 700px; margin: auto; padding: 20px; font-family: Arial; }
    .search-bar { width: 70%; padding: 10px; margin-right: 10px; }
    .map { height: 300px; background: lightgray; margin: 20px 0; display: flex; align-items: center; justify-content: center; border-radius: 10px; }
    .home-buttons button { margin-right: 10px; padding: 10px 15px; cursor: pointer; border-radius: 5px; border: 1px solid #333; transition: 0.2s; }
    .home-buttons button:hover { background: #333; color: white; }
    .section { margin-top: 20px; padding: 15px; border: 1px solid #ccc; border-radius: 10px; background: rgba(255,255,255,0.9); }
  `]
})
export class Home {
  searchQuery = '';
  showAccount = false;
  showSettings = false;

  toggleAccount() { this.showAccount = !this.showAccount; this.showSettings = false; }
  toggleSettings() { this.showSettings = !this.showSettings; this.showAccount = false; }
  searchLocation() { console.log('Searching for', this.searchQuery); }
}
