import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForumDetail } from '../forum-detail/forum-detail';

@Component({
  selector: 'forum-list',
  standalone: true,
  imports: [CommonModule, ForumDetail],
  template: `
    <div class="forum-list">
      <h4>Forum Posts ({{ posts.length }})</h4>
      <forum-detail *ngFor="let post of posts" [post]="post"></forum-detail>
    </div>
  `
})
export class ForumList {
  posts = [
    { title: 'First Post', content: 'Hello world!', likes: 0, imageUrl: 'https://via.placeholder.com/100' },
    { title: 'Second Post', content: 'Angular is cool!', likes: 0, imageUrl: 'https://via.placeholder.com/100' }
  ];
}
