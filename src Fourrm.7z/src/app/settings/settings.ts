import { Component } from '@angular/core';

@Component({
  selector: 'settings-screen',
  standalone: true,
  template: `
    <h3>Settings</h3>
    <p>Settings options go here</p>
  `
})
export class Settings {}
