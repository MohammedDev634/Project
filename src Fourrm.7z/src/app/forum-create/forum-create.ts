import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'forum-create',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="forum-create">
      <h4>Create New Post</h4>
      <input [(ngModel)]="newPost.title" placeholder="Title">
      <textarea [(ngModel)]="newPost.content" placeholder="Content"></textarea>
      <button (click)="submitPost()">Submit</button>
    </div>
  `,
  styles: [`
    .forum-create input, .forum-create textarea { width: 100%; margin: 5px 0; padding: 8px; border-radius: 5px; }
    .forum-create button { padding: 8px 12px; border-radius: 5px; cursor: pointer; margin-top: 5px; }
    .forum-create button:hover { background: #333; color: white; }
  `]
})
export class ForumCreate {
  newPost = { title: '', content: '' };

  submitPost() {
    console.log('New Post:', this.newPost);
    this.newPost = { title: '', content: '' };
  }
}
