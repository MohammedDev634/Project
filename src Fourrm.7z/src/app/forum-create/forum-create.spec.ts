import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForumCreate } from './forum-create';

describe('ForumCreate', () => {
  let component: ForumCreate;
  let fixture: ComponentFixture<ForumCreate>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ForumCreate]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ForumCreate);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
