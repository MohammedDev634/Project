import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForumCreate } from '../forum-create/forum-create';
import { ForumList } from '../forum-list/forum-list';

@Component({
  selector: 'account',
  standalone: true,
  imports: [CommonModule, ForumCreate, ForumList],
  template: `
    <h3>Your Account</h3>
    <p>Save addresses/posts below:</p>
    <forum-create></forum-create>
    <forum-list></forum-list>
  `
})
export class Account {}
