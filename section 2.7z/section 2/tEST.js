function Hi()
alert("Hi");