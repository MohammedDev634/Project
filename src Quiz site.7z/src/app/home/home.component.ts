import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  name: string = '';
  id: string = '';

  constructor(private auth: AuthService, private router: Router) {}

  startQuiz() {
    if (this.auth.hasTakenQuiz()) {
      this.router.navigate(['/results']);
      return;
    }

    const idRegex = /^\d{8}$/;
    if (!this.name.trim() || !idRegex.test(this.id)) {
      alert('Enter your name and an 8-digit numeric ID.');
      return;
    }

    this.auth.setUser(this.name, this.id);
    this.router.navigate(['/quiz']);
  }
}
