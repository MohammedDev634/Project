import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  setUser(name: string, id: string) {
    localStorage.setItem('user', JSON.stringify({ name, id }));
  }

  getUser() {
    const data = localStorage.getItem('user');
    return data ? JSON.parse(data) : null;
  }

  hasTakenQuiz(): boolean {
    return localStorage.getItem('quizTaken') === 'true';
  }

  saveGrade(grade: number, questions: any[], answers: (number | null)[]) {
    localStorage.setItem('quizResult', JSON.stringify({ grade, questions, answers }));
    localStorage.setItem('quizTaken', 'true');
  }

  getResult() {
    const data = localStorage.getItem('quizResult');
    return data ? JSON.parse(data) : null;
  }
}
