import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="app-shell">
      <router-outlet></router-outlet>
    </div>
  `,
  styles: [`
    .app-shell { max-width: 700px; margin: 20px auto; padding: 20px; }
  `]
})
export class AppComponent {}
