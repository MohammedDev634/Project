import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

type Question = { text: string; options: string[]; correctIndex: number };

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  questions: Question[] = [];
  answers: (number | null)[] = [];
  currentIndex = 0;

  constructor(private auth: AuthService, private router: Router) {}

  ngOnInit() {
    if (this.auth.hasTakenQuiz()) {
      this.router.navigate(['/results']);
      return;
    }

    this.questions = [
      { text: 'What is 2 + 2?', options: ['1', '2', '3', '4'], correctIndex: 3 },
      { text: 'Capital of France?', options: ['Berlin', 'Madrid', 'Paris', 'Rome'], correctIndex: 2 },
      { text: 'Which is a programming language?', options: ['HTML', 'CSS', 'TypeScript', 'PNG'], correctIndex: 2 }
    ];

    this.answers = Array(this.questions.length).fill(null);
  }

  selectAnswer(optIndex: number) {
    this.answers[this.currentIndex] = optIndex;
  }

  prevQuestion() {
    if (this.currentIndex > 0) this.currentIndex--;
  }

  nextQuestion() {
    if (this.currentIndex < this.questions.length - 1) this.currentIndex++;
  }

  submitQuiz() {
    let score = 0;
    this.questions.forEach((q, i) => {
      if (this.answers[i] === q.correctIndex) {
        score++;
      }
    });
    const grade = Math.round((score / this.questions.length) * 100);
    this.auth.saveGrade(grade, this.questions, this.answers);
    this.router.navigate(['/results']);
  }
}
