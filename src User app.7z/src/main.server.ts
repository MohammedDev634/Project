import { AppComponent } from './app/app';
export default AppComponent;
