import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { User } from './user.service';
import { UserListComponent } from './user-list.component';
import { UserDetailComponent } from './user-detail.component';

@Component({
  selector: 'app-binding-examples',
  templateUrl: './binding-examples.component.html',
  styleUrls: ['./binding-examples.component.css'],
  standalone: true,
  imports: [FormsModule, UserListComponent, UserDetailComponent]
})
export class BindingExamplesComponent {
  message = 'Hello, Angular!';
  imageUrl = 'https://angular.io/assets/images/logos/angular/angular.png';

  count = 0;
  username = '';
  selectedUser: User | null = null;

  onButtonClick() {
    this.count++;
  }
}
