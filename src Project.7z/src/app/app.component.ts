import { Component } from '@angular/core';
import { BindingExamplesComponent } from './binding-examples.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: true,
  imports: [BindingExamplesComponent]
})
export class AppComponent {
  title = 'project';
}
