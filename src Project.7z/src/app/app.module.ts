// This module is no longer needed - the app now uses standalone components
// Bootstrapped via main.ts using bootstrapApplication(AppComponent, appConfig)

/*
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent   // ✅ root wrapper only
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]   // ✅ only ONE root
})
export class AppModule { }
*/
