import { Component, signal } from '@angular/core';
import { BindingExamplesComponent } from './binding-examples.component';

@Component({
  selector: 'app-main',
  templateUrl: './app.html',
  styleUrls: ['./app.css'],
  standalone: true,
  imports: [BindingExamplesComponent]
})
export class App {
  count = 0;
  username = '';
  protected readonly title = signal('project');

  onClick() {
    this.count++;
  }
}
