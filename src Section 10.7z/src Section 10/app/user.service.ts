import { HttpClient } from "@angular/common/http";
import { Component, Injectable } from "@angular/core";

@Injectable({providedIn: 'root'})
export class userservice {
    constructor(private http:HttpClient) {}
    getUser(){
        return this.http.get('https://jsonplaceholder.typicode.com/users');
    }

    addUser(data:any){
        return this.http.post('https://jsonplaceholder.typicode.com/users', data);
    }

    updateUser(data:any, id:number){
        return this.http.put(`https://jsonplaceholder.typicode.com/users/${id}`, data);
    }
}

