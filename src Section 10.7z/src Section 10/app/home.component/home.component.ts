import { Component } from '@angular/core';
import { userservice } from '../user.service';

@Component({
  selector: 'app-home.component',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [userservice]
})

export class HomeComponent {
  users: any[] = [];

  constructor(private api: userservice) {}

  ngOnInit() {
    this.api.getUser().subscribe({
      next: (res: any) => {
        this.users = res;
      },
      error: (err) => {
        console.error('Error fetching users:', err);
      },
      complete: () => {
        console.log('User fetch completed');
      }
    });
  }
}
