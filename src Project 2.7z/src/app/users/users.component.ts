import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  template: `
    <h2>User List</h2>
    <p *ngIf="loading">Loading...</p>
    <ul *ngIf="!loading">
      <li *ngFor="let u of users">{{ u }}</li>
    </ul>
  `
})
export class UsersComponent implements OnInit {
  users: string[] = [];
  loading = false;
  ngOnInit() {
    this.loading = true;
    setTimeout(() => {
      this.users = ['Alice', 'Bob', 'Charlie'];
      this.loading = false;
      console.log('ngOnInit: Data fetched');
    }, 1500);
  }
}
