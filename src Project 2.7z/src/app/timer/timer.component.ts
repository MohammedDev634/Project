import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, interval } from 'rxjs';

@Component({
  selector: 'app-timer',
  template: `<p>Timer: {{ seconds }}</p>`
})
export class TimerComponent implements OnInit, OnDestroy {
  seconds = 0;
  private sub!: Subscription;
  ngOnInit() {
    this.sub = interval(1000).subscribe(n => this.seconds = n);
    console.log('ngOnInit: Timer started');
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
    console.log('ngOnDestroy: Timer stopped & unsubscribed');
  }
}
