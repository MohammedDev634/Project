import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ParentComponent } from './parent/parent.component';
import { UsersComponent } from './users/users.component';
import { TimerComponent } from './timer/timer.component';
import { TodoComponent } from './todo/todo.component';

const routes: Routes = [
  { path: 'parent', component: ParentComponent },
  { path: 'users', component: UsersComponent },
  { path: 'timer', component: TimerComponent },
  { path: 'todo', component: TodoComponent },
  { path: '', redirectTo: '/parent', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
