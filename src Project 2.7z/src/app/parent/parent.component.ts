import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  template: `
    <h2>Parent Component</h2>
    <p>Current User Id: {{ userId }}</p>
    <button (click)="changeId()">Change Id</button>
    <app-child [id]="userId"></app-child>
  `
})
export class ParentComponent {
  userId = 1;
  changeId() { this.userId++; }
}
