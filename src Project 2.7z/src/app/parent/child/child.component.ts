import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `<p>Child received id: {{ id }}</p>`
})
export class ChildComponent implements OnChanges {
  @Input() id!: number;
  ngOnChanges(changes: SimpleChanges) {
    if (changes['id']) {
      console.log('ngOnChanges:', changes['id'].previousValue, '→', changes['id'].currentValue);
    }
  }
}
